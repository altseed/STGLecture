﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
	class Program
	{
		static void Main(string[] args)
		{
			// ACEを初期化する。
			ace.Engine.Initialize("STG03", 640, 480, new ace.EngineOption());

			// シーンを生成する。
			ace.Scene scene = new ace.Scene();

			// レイヤーを生成する。
			ace.Layer2D layer = new ace.Layer2D();

			// シーンにレイヤーを追加する。
			scene.AddLayer(layer);

			// オブジェクトを生成する。
			ace.TextureObject2D obj = new ace.TextureObject2D();

			// レイヤーにオブジェクトを追加する。
			layer.AddObject(obj);

			// 画像を読み込み、オブジェクトに設定する。
			obj.Texture = ace.Engine.Graphics.CreateTexture2D("Resources/Player.png");

			// シーンを切り替える。
			ace.Engine.ChangeScene(scene);

			// ACEのウインドウが閉じられていないか確認する。
			while (ace.Engine.DoEvents())
			{
				// aceを更新する。
				ace.Engine.Update();
			}

			// ACEの終了処理をする。
			ace.Engine.Terminate();
		}
	}
}
