﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
    // タイトル画面・ゲームオーバー画面など、1枚絵を表示する際に利用するTextureObject2D
	public class BackGround : asd.TextureObject2D
	{
        protected asd.Scene nextscene;
        protected asd.Scene overscene;

        protected bool isTitle = false;

        public BackGround(asd.Texture2D tex, asd.Scene next)
            : base()
        {
            // 敵のインスタンスの位置を設定する。
            Position = new asd.Vector2DF(0, 0);

            // インスタンスに画像を設定する。
            Texture = tex;

            // 遷移先のシーンを設定する。
            nextscene = next;

            // タイトル画面であれば遷移時に初期化を行うので、フラグを立てておく
            isTitle = false;
        }

        public BackGround(asd.Texture2D tex, asd.Scene next, asd.Scene over)
            : base()
        {
            // 敵のインスタンスの位置を設定する。
            Position = new asd.Vector2DF(0, 0);

            // インスタンスに画像を設定する。
            Texture = tex;

            // 遷移先のシーンを設定する。
            nextscene = next;
            overscene = over;

            // タイトル画面であれば遷移時に初期化を行うので、フラグを立てておく
            isTitle = true;
        }

		protected override void OnUpdate()
		{
            // もし、Zキーを押したら{}内の処理を行う。
            if (asd.Engine.Keyboard.GetKeyState(asd.Keys.Z) == asd.KeyState.Push)
            {
                asd.Engine.ChangeSceneWithTransition(nextscene, new asd.TransitionFade(1.0f, 1.0f));

                if (isTitle)
                {
                    foreach (asd.Layer l in nextscene.Layers)
                    {
                        l.Vanish();
                    }
                    var GameLayer = new asd.Layer2D();
                    nextscene.AddLayer(GameLayer);
                    
                    // プレイヤーのインスタンスを生成する。
                    Player player = new Player(overscene);

                    GameLayer.AddObject(player);

                    // エンジンに反復して移動する敵のインスタンスを生成する。
                    GameLayer.AddObject(new VortexShotEnemy(new asd.Vector2DF(320.0f, 100.0f), player));
                }
            }
		}

	}
}