﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
    class GameLayer : ace.Layer2D
    {
        ICollidable player;

        public GameLayer() { }
       

        protected override void OnUpdated()
        {

            // ListでICollidableなObjectsを管理する
            List<ICollidable> playerBullets = new List<ICollidable>();
            List<ICollidable> enemyBullets = new List<ICollidable>();
            List<ICollidable> enemies = new List<ICollidable>();
            
            // ICollidableなObjectsを格納
            initGameObjects(playerBullets, enemyBullets, enemies);
            
            // 敵弾とプレイヤーの衝突
            if((player as Player).IsAlive)
                playerCollision(enemyBullets);

            // 自機弾と敵の衝突
            enemyCollision(enemies, playerBullets);
          
        }

        // 引数により受け取ったListにICollidableなObjectsを格納
        private void initGameObjects(List<ICollidable> playerBullets, List<ICollidable> enemyBullets,List<ICollidable> enemies )
        {
            foreach (var o in Objects)
            {
                if (!o.IsAlive)
                    continue;
                
                ICollidable gameObject = o as ICollidable;

                if (gameObject == null)
                    continue;

                // gameObjectのアップキャストにより、配列に格納する
                else
                {
                    if ((gameObject as Player)!=null)
                        player = gameObject as ICollidable;

                    else if ((gameObject as Bullet)!=null)
                        playerBullets.Add(gameObject);

                    else if ((gameObject as EnemyBullet)!=null)
                        enemyBullets.Add(gameObject);

                    else if ((gameObject as Enemy)!=null)
                        enemies.Add(gameObject);
                }
            }
        }

        private void playerCollision(List<ICollidable> enemyBullets)
        {
            foreach (var enemyBullet in enemyBullets)
            {
                if(player.IsCollide(enemyBullet))
                {
                    player.OnCollide(enemyBullet);
                    enemyBullet.OnCollide(player);
                }
            }
        }

        private void enemyCollision(List<ICollidable> enemies, List<ICollidable> playerBullets)
        {
            foreach (var enemy in enemies)
                foreach (var playerBullet in playerBullets)
                {
                    if (enemy.IsCollide(playerBullet))
                    {
                        enemy.OnCollide(playerBullet);
                        playerBullet.OnCollide(enemy);
                    }
                }
        }
    }
}
