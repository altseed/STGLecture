﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{

    class Bullet : ace.TextureObject2D, ICollidable
    {   
        public float Radius { get; set; }


        public Bullet(ace.Vector2DF position)
        {
            // 弾のテクスチャを読み込む。
            Texture = ace.Engine.Graphics.CreateTexture2D("Resources/PlayerBullet.png");

            CenterPosition = new ace.Vector2DF(Texture.Size.X/2.0f, Texture.Size.Y/2.0f);

            // 弾の位置を設定する。
            Position = position + new ace.Vector2DF(0, -Texture.Size.Y/2.0f);

            Radius = Texture.Size.X / 2.0f;
        }

        protected override void OnUpdate()
        {
            Position = Position + new ace.Vector2DF(0, -2);

            // 画面外に出たら
            if (Position.Y < -10)
            {
                // 削除する。
                Vanish();
            }
        }

        public bool IsCollide(ICollidable obj)
        {
            if ((obj.Position - Position).Length < Radius + obj.Radius)
                return true;
            else
                return false;
        }

        public void OnCollide(ICollidable obj)
        {
            Vanish();
        }
    }

    public class Player : ace.TextureObject2D, ICollidable
    {
        public float Radius { get; set; }

        public Player()
        {
            // 画像を読み込み、オブジェクトに設定する。
            Texture = ace.Engine.Graphics.CreateTexture2D("Resources/Player.png");

            //自機のテクスチャの描画原点を、画像の中心に設定する。(テクスチャサイズが(32,70)なのでその中心は(16,35))
            CenterPosition = new ace.Vector2DF(16, 35);

            Position = new ace.Vector2DF(320.0f, 500.0f);

            Radius = Texture.Size.X / 8.0f;
        }

       

        protected override void OnUpdate()
        {
            var vel = new ace.Vector2DF(0, 0);

            // もし、上ボタンが押されていたら、位置に(0,-1)を足す。
            if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Up) == ace.KeyState.Hold)
            {
                vel += new ace.Vector2DF(0, -3);
            }

            // もし、下ボタンが押されていたら、位置に(0,+1)を足す。
            if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Down) == ace.KeyState.Hold)
            {
                vel += new ace.Vector2DF(0, +3);
            }

            // もし、左ボタンが押されていたら、位置に(-1,0)を足す。
            if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Left) == ace.KeyState.Hold)
            {
                vel += new ace.Vector2DF(-3, 0);
            }

            // もし、左ボタンが押されていたら、位置に(+1,0)を足す。
            if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Right) == ace.KeyState.Hold)
            {
                vel += new ace.Vector2DF(+3, 0);
            }

            if(vel.Length!=0)
                Position += vel.Normal * 3.0f;

            {
                // オブジェクトの位置を取得する。
                ace.Vector2DF position = Position;

                // オブジェクトの位置を、(0,0)～(ウインドウの大きさ-テクスチャの大きさ)の範囲に制限する。
                position.X = ace.MathHelper.Clamp(position.X, ace.Engine.WindowSize.X, 0);
                position.Y = ace.MathHelper.Clamp(position.Y, ace.Engine.WindowSize.Y, 0);

                // オブジェクトの位置を設定する。
                Position = position;
            }

            // もし、Zキーを押したら{}内の処理を行う。
            if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Z) == ace.KeyState.Hold)
            {
                // 弾を生成する。
                Bullet bullet = new Bullet(Position+new ace.Vector2DF(0,-Texture.Size.Y/2.0f));

                // 弾をレイヤーに追加する。
                Layer.AddObject(bullet);
            }
        }
        public bool IsCollide(ICollidable obj)
        {
            if ((obj.Position - Position).Length < Radius + obj.Radius)
                return true;
            else
                return false;
        }

        public void OnCollide(ICollidable obj)
        {
            Vanish();
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            // ACEを初期化する。
            ace.Engine.Initialize("STG08", 640, 480, new ace.EngineOption());

            // シーンを生成する。
            ace.Scene scene = new ace.Scene();

            // レイヤーを生成する。
            GameLayer layer = new GameLayer();
            ace.Layer2D backgroundLayer = new ace.Layer2D();

            // レイヤーの描画優先度を設定する（デフォルトで0）
            backgroundLayer.DrawingPriority = -10;

            // シーンにレイヤーを追加する。
            scene.AddLayer(layer);
            scene.AddLayer(backgroundLayer);

            // Background オブジェクトを生成する。
            Background bg1 = new Background(new ace.Vector2DF(0.0f, 0.0f), "Resources/Game_Bg.png", 0.3f);
            // bg1 の上端に bg2 の下端をくっつける。
            Background bg2 = new Background(new ace.Vector2DF(0.0f, -bg1.Texture.Size.Y), "Resources/Game_Bg.png", 0.3f);
            
            // 赤い背景を生成する。
            Background bgRed1 = new Background(new ace.Vector2DF(-2.0f, 30.0f), "Resources/Game_Bg_Red.png", 0.5f);
            Background bgRed2 = new Background(new ace.Vector2DF(-2.0f, 30.0f-bgRed1.Texture.Size.Y), "Resources/Game_Bg_Red.png", 0.5f);

            // 黄色い背景を生成する。
            Background bgYellow1 = new Background(new ace.Vector2DF(-10.0f, 80.0f), "Resources/Game_Bg_Yellow.png", 1.0f);
            Background bgYellow2 = new Background(new ace.Vector2DF(-10.0f, 80.0f - bgRed1.Texture.Size.Y), "Resources/Game_Bg_Yellow.png", 1.0f);

            // 背景を背景レイヤーに追加する。
            backgroundLayer.AddObject(bg1);
            backgroundLayer.AddObject(bg2);
            backgroundLayer.AddObject(bgRed1);
            backgroundLayer.AddObject(bgRed2); 
            backgroundLayer.AddObject(bgYellow1);
            backgroundLayer.AddObject(bgYellow2);

            // 自機オブジェクトを生成する。
            Player player = new Player();

            // レイヤーに自機オブジェクトを追加する。
            layer.AddObject(player);
           
            //敵オブジェクトを生成する。
            //GentlyMovingEnemy gentlyMovingEnemy = new GentlyMovingEnemy(new ace.Vector2DF(320.0f, 100.0f), player);
            Boss boss = new Boss(new ace.Vector2DF(320.0f, 100.0f), player);

            //敵オブジェクトを追加する。
            //layer.AddObject(gentlyMovingEnemy);
            layer.AddObject(boss);

            // シーンを切り替える。
            ace.Engine.ChangeScene(scene);

            // ACEのウインドウが閉じられていないか確認する。
            while (ace.Engine.DoEvents())
            {
                // aceを更新する。
                ace.Engine.Update();
            }

            // ACEの終了処理をする。
            ace.Engine.Terminate();
        }
    }
}
