﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
    public class MovingEnemy :Enemy
    {
        //キャラクターが移動できる範囲の左端位置を保存する変数。
        private ace.Vector2DF leftLimit;

        //キャラクターが移動できる範囲の右端位置を保存する変数。
        private ace.Vector2DF rightLimit;

        //キャラクターが現状左に移動している : true, 右に移動している : false。
        private bool isGoingLeft;

        public MovingEnemy(ace.Vector2DF pos, Player player)
            : base(pos, player)
        {
            //移動可能な左端位置を設定。(初期位置から左に50)
            leftLimit = Position - new ace.Vector2DF(50, 0);

            //移動可能な右端位置を設定。(初期位置から右に50)
            rightLimit = Position + new ace.Vector2DF(50, 0);

            //最初は左に向かって移動する。
            isGoingLeft = true;
        }
        

        protected override void OnUpdate()
        {            
            //左に向かって移動する。
            if (isGoingLeft)
            {
                Position -= new ace.Vector2DF(2.0f, 0);

                //位置が移動可能な範囲の左端を超えたとき。
                if (Position.X <= leftLimit.X)
                {
                    //右への移動に切り替える。
                    isGoingLeft = false;

                    //左端を超えないように、補正する。
                    Position = new ace.Vector2DF(leftLimit.X, Position.Y);
                }
            }
            else //右に向かって移動する。
            {
                Position += new ace.Vector2DF(2.0f, 0);

                //位置が移動可能な範囲の右端を超えたとき。
                if (Position.X >= rightLimit.X)
                {
                    //左への移動に切り替える。
                    isGoingLeft = true;

                    //右端を超えないように、補正する。
                    Position = new ace.Vector2DF(rightLimit.X, Position.Y);
                }
            }
            
            //カウンタの値が60の倍数の時のみ、弾を撃つ。
            if (count % 60 == 0)
            {
                //AroundShot();
            }
            ++count;
        }
    }
}
