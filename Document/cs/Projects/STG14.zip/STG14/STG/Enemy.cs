﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
    public abstract class Enemy : ace.TextureObject2D, ICollidable
    {
        // 毎フレーム1増加し続けるカウンタ変数（継承先のクラスで使いまわすため、protectedに設定する。）
        protected int count;

        // プレイヤーへの参照（継承先のクラスで使いまわすため、protectedに設定する。）
        protected Player player;

        // 
        public float Radius {get; set;}

        // コンストラクタ(敵の初期位置を引数として受け取る。)
        public Enemy(ace.Vector2DF pos, Player player)
            : base()
        {
            // 敵のインスタンスの位置を設定する。
            Position = pos;

            //　画像を読み込み、敵のインスタンスに画像を設定する。
            Texture = ace.Engine.Graphics.CreateTexture2D("Resources/Enemy.png");

            // 敵のインスタンスに画像の中心位置を設定する。
            CenterPosition = new ace.Vector2DF(Texture.Size.X / 2.0f, Texture.Size.Y / 2.0f);

            // 
            Radius = Texture.Size.X / 2.0f;

            // カウンタ変数を0に初期化する。
            count = 0;

            // Playerクラスへの参照を保持する。
            this.player = player;
        }

        public virtual bool IsCollide(ICollidable obj)
        {
            if ((obj.Position - Position).Length < Radius + obj.Radius)
                return true;
            else
                return false;
        }

        public virtual void OnCollide(ICollidable obj)
        {
            Vanish();
        }

        protected override void OnUpdate()
        {
            ++count;
        }

        // 画面外に出た時に削除する関数。
        protected void VanishFromGame()
        {
            // 画面外に出たら
            var windowSize = ace.Engine.WindowSize;
            if (Position.Y < -Texture.Size.Y || Position.Y > windowSize.Y + Texture.Size.Y || Position.X < -Texture.Size.X || Position.X > windowSize.X + Texture.Size.X)
            {
                // 削除する。
                Vanish();
            }
        }

        // 渦状に弾を拡散する関数。
        protected void VortexShot(float degree)
        {
            ace.Vector2DF dirVector = new ace.Vector2DF(1, 0);
            dirVector.Degree = degree;
            ace.Engine.AddObject2D(new StraightMovingEnemyBullet(Position, dirVector));
        }
    }
}