﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
    public class Background : ace.TextureObject2D
    {
        // moveVelocity という小数を定義しておく。
        private float moveVelocity;

        public Background(ace.Vector2DF pos, string texturePath, float vel)
            : base()
        {
            // 初期位置を設定する。
            Position = pos;

            // texturePathで指定した場所にある画像を読み込み、設定する。
            Texture = ace.Engine.Graphics.CreateTexture2D(texturePath);

            // velを保持できるようにする。
            moveVelocity = vel;

            // Backgroundクラスのオブジェクトで加算合成ができるようにする
            AlphaBlend = ace.AlphaBlendMode.Add;

            // moveVelocityの値に応じてDrawingPriorityを設定する
            DrawingPriority = (int)( moveVelocity * 100 );
        }

      protected override void OnUpdate()
       {
           // 毎回、Y座標をmoveVelocityの値だけ位置を動かす。
           Position += new ace.Vector2DF(0.0f, moveVelocity);

           // Y座標が画面外にはみ出たならば、
           if (Position.Y >= ace.Engine.WindowSize.Y)
           {
               // Y座標から画像の縦2枚分の大きさを引く。
               Position -= new ace.Vector2DF(0.0f, 2 * Texture.Size.Y);
           }
       }
    }
}
