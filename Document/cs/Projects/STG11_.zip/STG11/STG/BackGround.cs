﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
    // タイトル画面・ゲームオーバー画面など、1枚絵を表示する際に利用するTextureObject2D
	public class BackGround : asd.TextureObject2D
	{
        protected asd.Scene nextscene;

        public BackGround(asd.Texture2D tex, asd.Scene next)
            : base()
        {
            // 敵のインスタンスの位置を設定する。
            Position = new asd.Vector2DF(0, 0);

            // インスタンスに画像を設定する。
            Texture = tex;

            // 遷移先のシーンを設定する。
            nextscene = next;

        }

		protected override void OnUpdate()
		{
            // もし、Zキーを押したら{}内の処理を行う。
            if (asd.Engine.Keyboard.GetKeyState(asd.Keys.Z) == asd.KeyState.Push)
            {
                asd.Engine.ChangeSceneWithTransition(nextscene, new asd.TransitionFade(1.0f, 1.0f));
            }
		}

	}
}