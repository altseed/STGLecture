﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
	class Program
	{
		[STAThread]
		static void Main(string[] args)
		{
			// AC-Engineを初期化する。
			ace.Engine.Initialize("STG", 640, 480, new ace.EngineOption());

			// プレイヤーのインスタンスを生成する。
			ace.TextureObject2D player = new ace.TextureObject2D();
			
			// 画像を読み込み、プレイヤーのインスタンスに画像を設定する。
			player.Texture = ace.Engine.Graphics.CreateTexture2D("Resources/Player.png");
	
			// エンジンにプレイヤーのインスタンスを追加する。
			ace.Engine.AddObject2D(player);
			
			// プレイヤーの位置を変更する。
			player.Position = new ace.Vector2DF(320, 240);

			// AC-Engineのウインドウが閉じられていないか確認する。
			while (ace.Engine.DoEvents())
			{
				// もし、Escキーが押されていたらwhileループを抜ける。
				if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Escape) == ace.KeyState.Push)
				{
					break;
				}

				// AC-Engineを更新する。
				ace.Engine.Update();
			}

			// AC-Engineの終了処理をする。
			ace.Engine.Terminate();
		}
	}
}
