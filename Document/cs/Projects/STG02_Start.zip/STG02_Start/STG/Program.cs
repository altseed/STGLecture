﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
	class Program
	{
		[STAThread]
		static void Main(string[] args)
		{
			// ACEを初期化する。
			ace.Engine.Initialize("STG", 640, 480, new ace.EngineOption());

			// ACEのウインドウが閉じられていないか確認する。
			while (ace.Engine.DoEvents())
			{
				// もし、Escキーが押されていたらwhileループを抜ける。
				if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Escape) == ace.KeyState.Push)
				{
					break;
				}

				// aceを更新する。
				ace.Engine.Update();
			}

			// ACEの終了処理をする。
			ace.Engine.Terminate();
		}
	}
}
