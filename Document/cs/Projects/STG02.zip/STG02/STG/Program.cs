﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
	class Program
	{
		[STAThread]
		static void Main(string[] args)
		{
			// ACEを初期化する。
			ace.Engine.Initialize("STG", 640, 480, new ace.EngineOption());

			// プレイヤーオブジェクトを生成する。
			ace.TextureObject2D player = new ace.TextureObject2D();
			
			// エンジンにプレイヤーオブジェクトを追加する。
			ace.Engine.AddObject2D(player);
			
			// 画像を読み込み、プレイヤーオブジェクトに画像を設定する。
			player.Texture = ace.Engine.Graphics.CreateTexture2D("Resources/Player.png");

			// プレイヤーの位置を変更する。
			player.Position = new ace.Vector2DF(320, 240);

			// ACEのウインドウが閉じられていないか確認する。
			while (ace.Engine.DoEvents())
			{
				// もし、Escキーが押されていたらwhileループを抜ける。
				if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Escape) == ace.KeyState.Push)
				{
					break;
				}

				// aceを更新する。
				ace.Engine.Update();
			}

			// ACEの終了処理をする。
			ace.Engine.Terminate();
		}
	}
}
