﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
	class Program
	{
		static void Main(string[] args)
		{
			// ACEを初期化する。
			ace.Engine.Initialize("STG02", 640, 480, new ace.EngineOption());

			// ACEのウインドウが閉じられていないか確認する。
			while (ace.Engine.DoEvents())
			{
				// aceを更新する。
				ace.Engine.Update();
			}

			// ACEの終了処理をする。
			ace.Engine.Terminate();
		}
	}
}
