﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
	class Laser : ace.EffectObject2D
	{
		public Laser()
		{
			Effect = ace.Engine.Graphics.CreateEffect("effect.efk");
		}
	}

	class Player : ace.TextureObject2D
	{
		Laser laser = null;

		public Player(ace.Vector2DF position)
		{
			Position = position;
			Src = new ace.RectF(0, 0, 16, 16);
			CenterPosition = new ace.Vector2DF(8, 8);
		}

		protected override void OnStart()
		{
			laser = new Laser();
			Layer.AddObject(laser);
		}

		protected override void OnUpdate()
		{
			// レーザーの位置を同期する。
			laser.Position = Position;

			// もし、上ボタンが押されていたら、位置に(0,-1)を足す。
			if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Up) == ace.KeyState.Hold)
			{
				Position = Position + new ace.Vector2DF(0, -1);
			}

			// もし、下ボタンが押されていたら、位置に(0,+1)を足す。
			if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Down) == ace.KeyState.Hold)
			{
				Position = Position + new ace.Vector2DF(0, +1);
			}

			// もし、左ボタンが押されていたら、位置に(-1,0)を足す。
			if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Left) == ace.KeyState.Hold)
			{
				Position = Position + new ace.Vector2DF(-1, 0);
			}

			// もし、左ボタンが押されていたら、位置に(+1,0)を足す。
			if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Right) == ace.KeyState.Hold)
			{
				Position = Position + new ace.Vector2DF(+1, 0);
			}

			// もし、Zキーを押したら{}内の処理を行う。
			if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Z) == ace.KeyState.Push)
			{
				// エフェクトとエフェクトオブジェクト2Dの位置を同期するように設定する。
				laser.SyncEffects = true;

				// エフェクトの角度を設定する。
				laser.EffectRotation = 90;
				laser.Angle = -90;
				
				// エフェクトの拡大率を設定する。
				laser.Scale = new ace.Vector2DF(10, 10);

				// レーザーのエフェクトを再生する。
				laser.Play();
			}
		}
	}

	class Program
	{
		[STAThread]
		static void Main(string[] args)
		{
			// AC-Engineを初期化する。
			ace.Engine.Initialize("STG", 640, 480, new ace.EngineOption());

			// プレイヤーのインスタンスを生成する。
			Player player = new Player(new ace.Vector2DF(320,240));

			// エンジンにプレイヤーのインスタンスを追加する。
			ace.Engine.AddObject2D(player);

			// AC-Engineのウインドウが閉じられていないか確認する。
			while (ace.Engine.DoEvents())
			{
				// もし、Escキーが押されていたらwhileループを抜ける。
				if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Escape) == ace.KeyState.Push)
				{
					break;
				}

				// AC-Engineを更新する。
				ace.Engine.Update();
			}

			// AC-Engineの終了処理をする。
			ace.Engine.Terminate();
		}
	}
}
