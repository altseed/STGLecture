﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
    public class SplitEnemyBullet :EnemyBullet
    {
        //1フレームごとに1増加していくカウンタ変数。
        private int count;

        //分裂するときのカウンタの値を保存する変数。
        private int splitCount;

        public SplitEnemyBullet(ace.Vector2DF startPos, ace.Vector2DF destination, int splitcount)
            : base(startPos, destination)
        {
            //カウンタの初期値を0に設定。
            count = 0;

            //分裂するときのカウンタの値を設定。
            splitCount = splitcount;

            //分裂する弾独自のテクスチャを設定する。
            Texture = ace.Engine.Graphics.CreateTexture2D("Resources/SplitEnemyBullet.png");
        }

        protected override void OnUpdate()
        {
            //基底クラス(EnemyBullet)のOnUpdateメソッド内にある目的地に向かって移動する処理と
            //画面外に出た時に消去する処理は使いまわせるので、使いまわす。
            base.OnUpdate();

            //カウンタの値が分裂時の値に達した時。
            if (splitCount==count)
            {
                //全6方向に対して弾(EnemyBullet)を発射する。
                for(int i=0;i<6;++i)
                {
                    ace.Vector2DF dir = new ace.Vector2DF(1, 0);
                    dir.Degree = i * 60;
                    Layer.AddObject(new EnemyBullet(Position, Position + dir));
                }

                //これ自身は消去する。
                Vanish();
            }
            ++count;
        }
    }
}
