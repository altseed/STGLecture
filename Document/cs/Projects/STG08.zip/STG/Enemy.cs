﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
    public class Enemy : ace.TextureObject2D
    {
        //毎フレーム1増加し続けるカウンタ変数
        protected int count;

        //プレイヤーへの参照
        protected Player player;

        //コンストラクタ(敵の初期位置を引数として受け取る。)
        public Enemy(ace.Vector2DF pos, Player player)
            : base()
        {
            //現在地を初期位置を設定。
            Position = pos;

            //敵のテクスチャに使用する画像を読み込んで、設定。
            Texture = ace.Engine.Graphics.CreateTexture2D("Resources/Enemy.png");

            //カウンタ変数を0に初期化
            count = 0;

            //Playerクラスへの参照を保持
            this.player = player;

            //敵のテクスチャの描画原点を、画像の中心に設定する。
            CenterPosition = new ace.Vector2DF(Texture.Size.X / 2.0f, Texture.Size.Y / 2.0f);
        }

        protected override void OnUpdate()
        {
            ++count;
        }

        //画面外に出た時に削除する関数。
        protected void VanishFromLayer()
        {
            // 画面外に出たら
            var windowSize = ace.Engine.WindowSize;
            if (Position.Y < -Texture.Size.Y || Position.Y > windowSize.Y + Texture.Size.Y || Position.X < -Texture.Size.X || Position.X > windowSize.X + Texture.Size.X)
            {
                // 削除する。
                Vanish();
            }
        }

        protected void VortexShot(float degree)
        {
            ace.Vector2DF dirVector = new ace.Vector2DF(1, 0);
            dirVector.Degree = degree;
            Layer.AddObject(new StraightMovingEnemyBullet(Position, dirVector));
        }

        protected void SplitShot(int splitCount)
        {
            //自機に向かって分裂する弾を撃つ。(速度ベクトルの長さは5.0でsplitCountで指定した回数フレームが経過すると分裂)
            ace.Vector2DF dir = player.Position - Position;
            ace.Vector2DF moveVector = dir.Normal * 5.0f;
            Layer.AddObject(new SplitEnemyBullet(Position, moveVector, splitCount));
        }
    }
}