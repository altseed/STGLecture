﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
    public class Enemy : ace.TextureObject2D
    {
        //自機への参照を持つ変数。
        protected Player playerRef;

        //1フレームごとに1増加していくカウンタ変数。
        protected int count;

        //コンストラクタ(敵の初期位置と自機への参照を引数として受け取る。)
        public Enemy(ace.Vector2DF pos,Player player)
            : base()
        {
            //現在地を初期位置を設定。
            Position = pos;

            //自機への参照を保持。
            playerRef = player;

            //カウンタの初期値を0にする。
            count = 0;

            //敵のテクスチャに使用する画像を読み込んで、設定。
            Texture = ace.Engine.Graphics.CreateTexture2D("Resources/Enemy.png");

            //敵のテクスチャの描画原点を、画像の中心に設定する。(テクスチャサイズが(30,30)なのでその中心は(15,15))
            CenterPosition = new ace.Vector2DF(15.0f, 15.0f);
        }

        protected void AroundShot()
        {
            //自機に向かって弾を撃つ。
            Layer.AddObject(new EnemyBullet(Position, playerRef.Position));

            //敵から見て自機の左方向に10度ずらしたところに向かって弾を撃つ。
            var dir1 = playerRef.Position - Position;
            dir1.Degree -= 10.0f;
            Layer.AddObject(new EnemyBullet(Position, Position + dir1));

            //敵から見て自機の右方向に10度ずらしたところに向かって弾を撃つ。
            var dir2 = playerRef.Position - Position;
            dir2.Degree += 10.0f;
            Layer.AddObject(new EnemyBullet(Position, Position + dir2));
        }

        protected void VortexShot(float degree)
        {
            ace.Vector2DF dirVector = new ace.Vector2DF(1, 0);
            dirVector.Degree = degree;
            Layer.AddObject(new EnemyBullet(Position, Position + dirVector));
        }

        protected void SplitShot(int splitCount)
        {
            //自機に向かって分裂する弾を撃つ。(splitCountで指定した回数フレームが経過すると分裂)
            Layer.AddObject(new SplitEnemyBullet(Position, playerRef.Position, splitCount));
        }
    }
}