﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
    public class EnemyBullet : ace.TextureObject2D
    {
        //弾の速度ベクトル。
        private ace.Vector2DF moveVelocity;

        //コンストラクタ(敵の初期位置を引数として受け取る。)
        public EnemyBullet(ace.Vector2DF pos, ace.Vector2DF movevelocity)
            : base()
        {
            //現在地を初期位置を設定する。
            Position = pos;

            //弾の速度ベクトルを設定する。
            moveVelocity = movevelocity;

            //弾のテクスチャに使用する画像を読み込んで、設定する。
            Texture = ace.Engine.Graphics.CreateTexture2D("Resources/EnemyBullet.png");

            //弾のテクスチャの描画原点を、画像の中心に設定する。
            CenterPosition = new ace.Vector2DF(Texture.Size.X / 2.0f, Texture.Size.Y / 2.0f);
        }

        protected override void OnUpdate()
        {
            //フレーム毎に現在地にmoveVelocityを加算して弾を移動させる。
            Position += moveVelocity;

            // 画面外に出たら
            var windowSize = ace.Engine.WindowSize;
            if (Position.Y < -Texture.Size.Y || Position.Y > windowSize.Y + Texture.Size.Y || Position.X < -Texture.Size.X || Position.X > windowSize.X + Texture.Size.X)
            {
                // 削除する。
                Vanish();
            }
        }
    }
}