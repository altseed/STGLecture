﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
    public class EnemyBullet : ace.TextureObject2D
    {
        //弾の速度ベクトル。
        private ace.Vector2DF moveVelocity;

        //コンストラクタ(敵の初期位置を引数として受け取る。)
        public EnemyBullet(ace.Vector2DF startPos, ace.Vector2DF destinationPos)
            : base()
        {
            //現在地を初期位置を設定する。
            Position = startPos;

            //弾の速度ベクトルを設定する。
            moveVelocity = (destinationPos - startPos).Normal * 3.0f;

            //弾のテクスチャに使用する画像を読み込んで、設定する。
            Texture = ace.Engine.Graphics.CreateTexture2D("Resources/EnemyBullet.png");

            //弾のテクスチャの描画原点を、画像の中心に設定する。(テクスチャサイズが(10,10)なのでその中心は(5,5))
            CenterPosition = new ace.Vector2DF(5.0f, 5.0f);
        }

        protected override void OnUpdate()
        {
            //フレーム毎に現在地にmoveVelocityを加算して弾を移動させる。
            Position += moveVelocity;

            // 画面外に出たら
            if (Position.Y < -10 || Position.Y > 490 || Position.X < -10 || Position.X > 650)
            {
                // 削除する。
                Vanish();
            }
        }
    }
}