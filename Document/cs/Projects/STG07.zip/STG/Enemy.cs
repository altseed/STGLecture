﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
    public class Enemy : ace.TextureObject2D
    {
        //キャラクターが移動できる範囲の左端位置を保存する変数。
        private ace.Vector2DF leftLimit;

        //キャラクターが移動できる範囲の右端位置を保存する変数。
        private ace.Vector2DF rightLimit;

        //キャラクターが現状左に移動している : true, 右に移動している : false。
        private bool isGoingLeft;

        //自機への参照を持つ変数。
        private Player playerRef;

        //1フレームごとに1増加していくカウンタ変数。
        private int count;

        //コンストラクタ(敵の初期位置と自機への参照を引数として受け取る。)
        public Enemy(ace.Vector2DF pos,Player player)
            : base()
        {
            //現在地を初期位置を設定。
            Position = pos;

            //自機への参照を保持。
            playerRef = player;

            //カウンタの初期値を0にする。
            count = 0;

            //敵のテクスチャに使用する画像を読み込んで、設定。
            Texture = ace.Engine.Graphics.CreateTexture2D("Resources/Enemy.png");

            //移動可能な左端位置を設定。(初期位置から左に50)
            leftLimit = Position - new ace.Vector2DF(50, 0);

            //移動可能な右端位置を設定。(初期位置から右に50)
            rightLimit = Position + new ace.Vector2DF(50, 0);

            //最初は左に向かって移動する。
            isGoingLeft = true;

            //敵のテクスチャの描画原点を、画像の中心に設定する。(テクスチャサイズが(30,30)なのでその中心は(15,15))
            CenterPosition = new ace.Vector2DF(15.0f, 15.0f);
        }

        protected override void OnUpdate()
        {
            //左に向かって移動する。
            if (isGoingLeft)
            {
                Position -= new ace.Vector2DF(2.0f, 0);

                //位置が移動可能な範囲の左端を超えたとき。
                if (Position.X <= leftLimit.X)
                {
                    //右への移動に切り替える。
                    isGoingLeft = false;

                    //左端を超えないように、補正する。
                    Position = new ace.Vector2DF(leftLimit.X, Position.Y);
                }
            }
            else //右に向かって移動する。
            {
                Position += new ace.Vector2DF(2.0f, 0);

                //位置が移動可能な範囲の右端を超えたとき。
                if (Position.X >= rightLimit.X)
                {
                    //左への移動に切り替える。
                    isGoingLeft = true;

                    //右端を超えないように、補正する。
                    Position = new ace.Vector2DF(rightLimit.X, Position.Y);
                }
            }

            //カウンタの値が60の倍数の時のみ、弾を撃つ。
            if (count % 60 == 0)
            {
                //自機に向かって弾を撃つ。
                Layer.AddObject(new EnemyBullet(Position, playerRef.Position));

                //敵から見て自機の左方向に10度ずらしたところに向かって弾を撃つ。
                var dir1 = playerRef.Position - Position;
                dir1.Degree -= 10.0f;
                Layer.AddObject(new EnemyBullet(Position, Position + dir1));

                //敵から見て自機の右方向に10度ずらしたところに向かって弾を撃つ。
                var dir2 = playerRef.Position - Position;
                dir2.Degree += 10.0f;
                Layer.AddObject(new EnemyBullet(Position, Position + dir2));
            }
            ++count;
        }
    }
}