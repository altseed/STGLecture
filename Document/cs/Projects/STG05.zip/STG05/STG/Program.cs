﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
	class Program
	{
		static void Main(string[] args)
		{
			// ACEを初期化する。
			ace.Engine.Initialize("STG05", 640, 480, new ace.EngineOption());

			// シーンを生成する。
			ace.Scene scene = new ace.Scene();

			// レイヤーを生成する。
			ace.Layer2D layer = new ace.Layer2D();

			// シーンにレイヤーを追加する。
			scene.AddLayer(layer);

			// オブジェクトを生成する。
			ace.TextureObject2D obj = new ace.TextureObject2D();

			// レイヤーにオブジェクトを追加する。
			layer.AddObject(obj);

			// 画像を読み込み、オブジェクトに設定する。
			obj.Texture = ace.Engine.Graphics.CreateTexture2D("Resources/Player.png");

			// シーンを切り替える。
			ace.Engine.ChangeScene(scene);

			// リストを生成する。
			List<ace.TextureObject2D> bullets = new List<ace.TextureObject2D>();

			// ACEのウインドウが閉じられていないか確認する。
			while (ace.Engine.DoEvents())
			{
				// もし、上ボタンが押されていたら、位置に(0,-1)を足す。
				if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Up) == ace.KeyState.Hold)
				{
					obj.Position = obj.Position + new ace.Vector2DF(0, -1);
				}

				// もし、下ボタンが押されていたら、位置に(0,+1)を足す。
				if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Down) == ace.KeyState.Hold)
				{
					obj.Position = obj.Position + new ace.Vector2DF(0, +1);
				}

				// もし、左ボタンが押されていたら、位置に(-1,0)を足す。
				if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Left) == ace.KeyState.Hold)
				{
					obj.Position = obj.Position + new ace.Vector2DF(-1, 0);
				}

				// もし、左ボタンが押されていたら、位置に(+1,0)を足す。
				if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Right) == ace.KeyState.Hold)
				{
					obj.Position = obj.Position + new ace.Vector2DF(+1, 0);
				}

				// もし、Zキーを押したら{}内の処理を行う。
				if(ace.Engine.Keyboard.GetKeyState(ace.Keys.Z) == ace.KeyState.Push)
				{
					// 弾を生成する。
					ace.TextureObject2D bullet = new ace.TextureObject2D();

					// 弾のテクスチャを読み込む。
					bullet.Texture = ace.Engine.Graphics.CreateTexture2D("Resources/PlayerBullet.png");
					
					// 弾の位置を設定する。
					bullet.Position = obj.Position + new ace.Vector2DF(obj.Texture.Size.X / 2.0f -bullet.Texture.Size.X / 2.0f, -6);

					// 弾をレイヤーに追加する。
					layer.AddObject(bullet);
					bullets.Add(bullet);
				}

				// bulletsに格納されている弾を移動させる
				for (int i = 0; i < bullets.Count; i++)
				{
					// 弾の座標を変更する
					bullets[i].Position = bullets[i].Position + new ace.Vector2DF(0, -2);
				}

				{
					// オブジェクトの位置を取得する。
					ace.Vector2DF position = obj.Position;

					// オブジェクトの位置を、(0,0)～(ウインドウの大きさ-テクスチャの大きさ)の範囲に制限する。
					position.X = ace.MathHelper.Clamp(position.X, ace.Engine.WindowSize.X - obj.Texture.Size.X, 0);
					position.Y = ace.MathHelper.Clamp(position.Y, ace.Engine.WindowSize.Y - obj.Texture.Size.Y, 0);

					// オブジェクトの位置を設定する。
					obj.Position = position;
				}

				// aceを更新する。
				ace.Engine.Update();
			}

			// ACEの終了処理をする。
			ace.Engine.Terminate();
		}
	}
}
