﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
    public interface ICollidable
    {
        // Position を取得することができる
        ace.Vector2DF Position{get;}

        // Radius(当たり判定の半径) を取得することができる
        float Radius{get;}

        // 衝突しているかどうかを判定するメソッドを実装する
        bool IsCollide(ICollidable obj);

        // 衝突時の処理を行うメソッドを実装する
        void OnCollide(ICollidable obj);
    }


    // GameLayerでgameObjectをアップキャストして基底クラスで分類する。無意味なインターフェースを作らない。
    //public interface IEnemy: ICollidable { }
    //public interface IEnemyBullet: ICollidable { }
    //public interface IPlayerBullet: ICollidable { }
}
