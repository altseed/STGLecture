﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
    class Bullet : ace.TextureObject2D, ICollidable
    {
        public float Radius { get; set; }

        public Bullet(ace.Vector2DF position)
        {
            // 画像を読み込み、弾のインスタンスに画像を設定する。
            Texture = ace.Engine.Graphics.CreateTexture2D("Resources/PlayerBullet.png");

            // 弾のインスタンスに画像の中心位置を設定する。
            CenterPosition = new ace.Vector2DF(Texture.Size.X / 2.0f, Texture.Size.Y / 2.0f);

            // 弾のインスタンスの位置を設定する。
            Position = position;
        }

        protected override void OnUpdate()
        {
            Position = Position + new ace.Vector2DF(0, -2);

            // 弾の画像が画面外に出たら
            if (Position.Y < -Texture.Size.Y)
            {
                // 削除する。
                Vanish();
            }
        }
        public bool IsCollide(ICollidable obj)
        {
            if ((obj.Position - Position).Length < Radius + obj.Radius)
                return true;
            else
                return false;
        }

        public void OnCollide(ICollidable obj)
        {
            Vanish();
        }
    }

    public class Player : ace.TextureObject2D, ICollidable
    {
        public float Radius { get; set; }

        public Player()
        {
            // 画像を読み込み、プレイヤーのインスタンスに画像を設定する。
            Texture = ace.Engine.Graphics.CreateTexture2D("Resources/Player.png");

            // プレイヤーのインスタンスに画像の中心位置を設定する。
            CenterPosition = new ace.Vector2DF(Texture.Size.X / 2.0f, Texture.Size.Y / 2.0f);

            // プレイヤーのインスタンスの位置を設定する。
            Position = new ace.Vector2DF(320, 480);

            // プレイヤーの Radius は小さめにしておく
            Radius = Texture.Size.X / 8.0f;
        }


        protected override void OnUpdate()
        {
            foreach (var obj in Layer.Objects)
                CollideWith(obj as ICollidable);

            // もし、上ボタンが押されていたら、位置に(0,-1)を足す。
            if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Up) == ace.KeyState.Hold)
            {
                Position = Position + new ace.Vector2DF(0, -1);
            }

            // もし、下ボタンが押されていたら、位置に(0,+1)を足す。
            if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Down) == ace.KeyState.Hold)
            {
                Position = Position + new ace.Vector2DF(0, +1);
            }

            // もし、左ボタンが押されていたら、位置に(-1,0)を足す。
            if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Left) == ace.KeyState.Hold)
            {
                Position = Position + new ace.Vector2DF(-1, 0);
            }

            // もし、左ボタンが押されていたら、位置に(+1,0)を足す。
            if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Right) == ace.KeyState.Hold)
            {
                Position = Position + new ace.Vector2DF(+1, 0);
            }

            // もし、Zキーを押したら{}内の処理を行う。
            if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Z) == ace.KeyState.Push)
            {
                // 弾のインスタンスを生成する。
                Bullet bullet = new Bullet(Position + new ace.Vector2DF(0, -30));

                // 弾のインスタンスをエンジンに追加する。
                ace.Engine.AddObject2D(bullet);
            }

            // プレイヤーの位置を取得する。
            ace.Vector2DF position = Position;

            // プレイヤーの位置を、(テクスチャの大きさ/2)～(ウインドウの大きさ-テクスチャの大きさ/2)の範囲に制限する。
            position.X = ace.MathHelper.Clamp(position.X, ace.Engine.WindowSize.X - Texture.Size.X / 2.0f, Texture.Size.X / 2.0f);
            position.Y = ace.MathHelper.Clamp(position.Y, ace.Engine.WindowSize.Y - Texture.Size.Y / 2.0f, Texture.Size.Y / 2.0f);

            // プレイヤーの位置を設定する。
            Position = position;
        }

        public bool IsCollide(ICollidable obj)
        {
            if ((obj.Position - Position).Length < Radius + obj.Radius)
                return true;
            else
                return false;
        }

        public void OnCollide(ICollidable obj)
        {
            Vanish();
        }

        // 敵の弾との当たり判定をコントロールするメソッド
        protected void CollideWith(ICollidable obj)
        {
            // 当たり判定の相手が見つかってない場合はメソッドを終了
            if (obj == null)
                return;

            // obj が EnemyBulletである場合にのみelse内を動作させる
            if ((obj as EnemyBullet) == null)
                return;
            else
            {
                // obj が enemyBullet であることを明示
                ICollidable enemyBullet = obj;

                // bulletと衝突した場合には、衝突時処理を行う
                if (IsCollide(enemyBullet))
                {
                    OnCollide(enemyBullet);
                    enemyBullet.OnCollide(this);
                }
            }
        }
    }

    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            // ACEを初期化する。
            ace.Engine.Initialize("STG", 640, 480, new ace.EngineOption());

            // シーンを生成する。
            ace.Scene scene = new ace.Scene();

            // レイヤーを生成する。
            ace.Layer2D layer = new ace.Layer2D();
            ace.Layer2D backgroundLayer = new ace.Layer2D();

            // レイヤーの描画優先度を設定する（デフォルトで0）
            backgroundLayer.DrawingPriority = -10;

            // シーンにレイヤーを追加する。
            scene.AddLayer(layer);
            scene.AddLayer(backgroundLayer);

            // Background オブジェクトを生成する。
            Background bg1 = new Background(new ace.Vector2DF(0.0f, 0.0f), "Resources/Game_Bg.png", 0.3f);
            // bg1 の上端に bg2 の下端をくっつける。
            Background bg2 = new Background(new ace.Vector2DF(0.0f, -bg1.Texture.Size.Y), "Resources/Game_Bg.png", 0.3f);

            // 赤い背景を生成する。
            Background bgRed1 = new Background(new ace.Vector2DF(-2.0f, 30.0f), "Resources/Game_Bg_Red.png", 0.5f);
            Background bgRed2 = new Background(new ace.Vector2DF(-2.0f, 30.0f - bgRed1.Texture.Size.Y), "Resources/Game_Bg_Red.png", 0.5f);

            // 黄色い背景を生成する。
            Background bgYellow1 = new Background(new ace.Vector2DF(-10.0f, 80.0f), "Resources/Game_Bg_Yellow.png", 1.0f);
            Background bgYellow2 = new Background(new ace.Vector2DF(-10.0f, 80.0f - bgRed1.Texture.Size.Y), "Resources/Game_Bg_Yellow.png", 1.0f);

            // 背景を背景レイヤーに追加する。
            backgroundLayer.AddObject(bg1);
            backgroundLayer.AddObject(bg2);
            backgroundLayer.AddObject(bgRed1);
            backgroundLayer.AddObject(bgRed2);
            backgroundLayer.AddObject(bgYellow1);
            backgroundLayer.AddObject(bgYellow2);

            // プレイヤーのインスタンスを生成する。
            Player player = new Player();

            // レイヤーに自機オブジェクトを追加する。
            layer.AddObject(player);

            // シーンを切り替える。
            ace.Engine.ChangeScene(scene);


            // ACEのウインドウが閉じられていないか確認する。
            while (ace.Engine.DoEvents())
            {
                // もし、Escキーが押されていたらwhileループを抜ける。
                if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Escape) == ace.KeyState.Push)
                {
                    break;
                }

                // aceを更新する。
                ace.Engine.Update();
            }

            // ACEの終了処理をする。
            ace.Engine.Terminate();
        }
    }
}
