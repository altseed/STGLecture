﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
	class Program
	{
		[STAThread]
		static void Main(string[] args)
		{
		// AC-Engineを初期化する。
		ace.Engine.Initialize("STG", 640, 480, new ace.EngineOption());

		// プレイヤーのインスタンスを生成する。
		ace.TextureObject2D player = new ace.TextureObject2D();

		// 画像を読み込み、プレイヤーのインスタンスに画像を設定する。
		player.Texture = ace.Engine.Graphics.CreateTexture2D("Resources/Player.png");

		// プレイヤーのインスタンスに画像の中心位置を設定する。
		player.CenterPosition = new ace.Vector2DF(player.Texture.Size.X / 2.0f, player.Texture.Size.Y / 2.0f);

		// エンジンにプレイヤーのインスタンスを追加する。
		ace.Engine.AddObject2D(player);

		// プレイヤーのインスタンスの位置を変更する。
		player.Position = new ace.Vector2DF(320, 240);

		// AC-Engineのウインドウが閉じられていないか確認する。
		while (ace.Engine.DoEvents())
		{
			// もし、Escキーが押されていたらwhileループを抜ける。
			if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Escape) == ace.KeyState.Push)
			{
				break;
			}

			// もし、上ボタンが押されていたら、位置に(0,-1)を足す。
			if(ace.Engine.Keyboard.GetKeyState(ace.Keys.Up) == ace.KeyState.Hold)
			{
				player.Position = player.Position + new ace.Vector2DF(0, -1);
			}

			// もし、下ボタンが押されていたら、位置に(0,+1)を足す。
			if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Down) == ace.KeyState.Hold)
			{
				player.Position = player.Position + new ace.Vector2DF(0, +1);
			}

			// もし、左ボタンが押されていたら、位置に(-1,0)を足す。
			if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Left) == ace.KeyState.Hold)
			{
				player.Position = player.Position + new ace.Vector2DF(-1, 0);
			}

			// もし、左ボタンが押されていたら、位置に(+1,0)を足す。
			if (ace.Engine.Keyboard.GetKeyState(ace.Keys.Right) == ace.KeyState.Hold)
			{
				player.Position = player.Position + new ace.Vector2DF(+1, 0);
			}

			// プレイヤーの位置を取得する。
			ace.Vector2DF position = player.Position;
		
			// プレイヤーの位置を、(テクスチャの大きさ/2)～(ウインドウの大きさ-テクスチャの大きさ/2)の範囲に制限する。
			position.X = ace.MathHelper.Clamp(position.X, ace.Engine.WindowSize.X - player.Texture.Size.X / 2.0f, player.Texture.Size.X / 2.0f);
			position.Y = ace.MathHelper.Clamp(position.Y, ace.Engine.WindowSize.Y - player.Texture.Size.Y / 2.0f, player.Texture.Size.Y / 2.0f);
		
			// プレイヤーの位置を設定する。
			player.Position = position;

			// AC-Engineを更新する。
			ace.Engine.Update();
		}

		// AC-Engineの終了処理をする。
		ace.Engine.Terminate();
		}
	}
}
