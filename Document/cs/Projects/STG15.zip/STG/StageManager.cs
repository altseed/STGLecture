﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STG
{
    public class StageManager
    {
        /**
         * 7/10 (ラン)
         * public bool IsInitialized 追加
         * 
         * タイトルからの遷移(init時): true
         * プレイヤーの死: false
         * ゲームクリア時(未実装): false
         * 
         * 用途: Main での Stage 管理　title や over でゲーム進行しないようにする
         */
         

        // 一度だけインスタンス化される
        public static StageManager Instance = new StageManager();

        // init時true
        public bool IsInitialized = false;

        // 敵の出現するレイヤーを持つ
        asd.Layer2D gameLayer;

        // プレイヤーの参照を持つ
        Player player;
        
        // ステージの最後にボスが出る
        Boss boss;

        // ステージ数を管理
        int stage;

        // ゲームの経過時間を管理
        int count;

        // ステージごとに敵を入れておくキュー
        Queue<Enemy>[] enemyQueues = new Queue<Enemy>[3];

        static StageManager() { }

        public void init(asd.Layer2D gameLayer, Player player)
        {
            // 敵を出現させるレイヤーを設定する
            this.gameLayer = gameLayer;

            // プレイヤーの参照を設定する
            this.player = player;

            // 最初のステージを0とする
            stage = 0;

            // ゲーム内のカウントを0にする
            count = 0;
            
            // ステージ0用の敵をセットする
            initStage0();

            // ステージ1用の敵をセットする
            initStage1();

            // ステージ2用の敵をセットする
            initStage2();

            // Main での onUpdate を有効にする
            IsInitialized = true;
        }

        // ステージ0に出現する敵を設定する
        private void initStage0()
        {
            // enemyQueue[0]にQueue<Enemy>をインスタンス化する。このキューにステージ0の敵を入れておく。
            enemyQueues[0] = new Queue<Enemy>();

            // 敵を射出する速度 moveVelocity を設定しておく
            asd.Vector2DF moveVelocity = new asd.Vector2DF(2.0f, 0.0f);

            // 10回ループする
            for (int i = 0; i < 10; i++)
            {
                // 速度を60度の向きに
                moveVelocity.Degree = 60;

                // 左側に敵を出現させる
                enemyQueues[0].Enqueue(new StraightMovingEnemy(new asd.Vector2DF(100.0f, 0.0f), moveVelocity, player));
                
                // 速度を120度の向きに
                moveVelocity.Degree = 120;

                // 右側に敵を出現させる
                enemyQueues[0].Enqueue(new StraightMovingEnemy(new asd.Vector2DF(540.0f, 0.0f), moveVelocity, player));
            }

            // 20回ループする
            for (int i = 0; i < 20; i++)
            {
                // 速度を90度の向きに
                moveVelocity.Degree = 90;

                // 左側に敵を出現させる
                enemyQueues[0].Enqueue(new StraightMovingEnemy(new asd.Vector2DF(100.0f, 0.0f), moveVelocity, player));
            }

            // 20回ループする
            for (int i = 0; i < 20; i++)
            {
                // 速度を90度の向きに
                moveVelocity.Degree = 90;

                // 右側に敵を出現させる
                enemyQueues[0].Enqueue(new StraightMovingEnemy(new asd.Vector2DF(540.0f, 0.0f), moveVelocity, player));
            }
        }
        private void initStage1()
        {
            // ステージ0同様に設定していく
            enemyQueues[1] = new Queue<Enemy>();
        }
        private void initStage2()
        {
            // ステージ0同様に設定していく
            enemyQueues[2] = new Queue<Enemy>();
        }


        // 自分で作ったonUpdateなので、メインループで呼ぶ必要がある
        public void onUpdate()
        {
            // ステージに対応するキューが空でないならば
            if (enemyQueues[stage].Count > 0)
            {
                // countが72の倍数の時に
                // 調整用にスタート時、一定の時間(count>100)を置く(7/10)
                if (count % 72 == 0 && count > 100)
                {
                    // 敵を出現させる
                    gameLayer.AddObject(enemyQueues[stage].Dequeue());
                }
            }

            // そのステージの敵が出現し終わったら
            else
            {
                // ボスが出現してないときに
                if (boss == null)
                {
                    // ボスを出現させる
                    boss = new Boss(new asd.Vector2DF(320.0f, 0.0f), player);

                    // ボスをレイヤーに追加する
                    gameLayer.AddObject(boss);
                }

                else
                {
                    // ボスが倒れたとき
                    if (!boss.IsAlive)
                    {
                        // ステージが2未満の時
                        if (stage < 2)
                        {
                            // ボスを初期化しておいて
                            boss = null;

                            // ステージを先に進める
                            ++stage;
                        }
                    }
                }
            }
            // onUpdate ごとに count を進める
            ++count;
        }
    }
}
